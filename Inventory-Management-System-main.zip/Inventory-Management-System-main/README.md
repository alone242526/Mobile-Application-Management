# Inventory-Management-System
This is a mobile application using Android Studio to manage inventory. The system provides a borrow and return equipment function using QR Code and dynamic QR Code. 


![1](1.jpg?raw=true)
![2](2.jpg?raw=true)
![3](3.jpg?raw=true)
![4](4.jpg?raw=true)
![5](5.jpg?raw=true)
![6](6.jpg?raw=true)
![7](7.jpg?raw=true)
![8](8.jpg?raw=true)
![9](9.jpg?raw=true)
![10](10.jpg?raw=true)
![11](11.jpg?raw=true)
![12](12.jpg?raw=true)
